//فاطمه رضوانی زاده
//40223034
#include<stdio.h>
int main()
{
int n;
char phrase[50] ;

printf(" enter the number of thr words");
scanf("%d" , &n);

char f[20] , l[20];
f[n]='\0';
l[n]='\0';

for(int i=0 ; i<n ; i++)
    scanf("%s%s" , f , l);

printf("enter a sentence of language 1");
fgets(phrase,sizeof(phrase),stdin);

for(int j=0;j<n-sizeof(f)+1;j++)
    for(int k=0;k<n;k++){
        if(stdln(l(j+k))>stdln(f(j+k)))
        {
            char m=f(j+k);
            f(j+k)=l(j+k);
            l(j=k)=m;
        }
                        }

printf("%s" , phrase);
}
